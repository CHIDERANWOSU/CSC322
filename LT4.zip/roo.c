﻿#include <stdio.h>
#include <stdlib.h>

int main(void){

  float width;
  float distance;
  int population;

  printf("Enter side of square in km  : ");
  scanf("%f", &width);
  float meterWidth = width * 1000;
  printf("Enter roads length in km    : ");
  scanf("%f", &distance);
  float meterDistance = distance * 1000;
  printf("Enter the number of 'roos   : ");
  scanf("%d", &population);
  printf("Expected number of kills is : %1.1f\n", ((population / (meterWidth * meterWidth))*(meterDistance * 10))*1.47);

  return(EXIT_SUCCESS);
}